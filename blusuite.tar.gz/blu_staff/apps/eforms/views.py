from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from django.db.models import Q
import json
import base64
from io import BytesIO

import sys as _sys
import os as _os

# Fix: blu_staff/apps/requests/ (Employee Requests app) shadows Python's pip 'requests'
# library. xhtml2pdf -> pyhanko -> pyhanko_certvalidator needs the real 'requests'.
# Solution: purge the local 'requests' from sys.modules, load the real one from
# site-packages, then import xhtml2pdf. The local Django app still works because
# Django resolves apps via AppConfig, not sys.modules.
_pisa = None
try:
    # Remove all local requests.* entries from sys.modules
    _to_remove = [k for k in _sys.modules if k == 'requests' or k.startswith('requests.')]
    _saved = {k: _sys.modules.pop(k) for k in _to_remove}

    # Find and add site-packages to the FRONT of sys.path temporarily
    import site as _site
    _sp_dirs = _site.getsitepackages() + [_site.getusersitepackages()]
    _real_sp = None
    for _d in _sp_dirs:
        if _os.path.isfile(_os.path.join(_d, 'requests', '__init__.py')):
            _real_sp = _d
            break

    if _real_sp:
        # Temporarily prioritize site-packages
        _sys.path.insert(0, _real_sp)
        import importlib
        _real_requests = importlib.import_module('requests')
        _sys.path.remove(_real_sp)

        # Now xhtml2pdf/pyhanko will find the real requests.Response
        from xhtml2pdf import pisa as _pisa

    # Restore the local Django 'requests' app modules so the rest of the
    # project can still do `from requests.models import EmployeeRequest`.
    # xhtml2pdf/pyhanko classes are already defined and don't need the
    # pip 'requests' module at runtime for PDF generation.
    for _k, _v in _saved.items():
        _sys.modules[_k] = _v
except Exception:
    # If anything fails, restore local modules and continue without PDF
    for _k, _v in _saved.items():
        _sys.modules[_k] = _v

from .models import (
    FormTemplate, FormSubmission, FormField, 
    ESignature, SignatureAuditLog, FormApproval
)


def _blusuite_ctx(user):
    """Get BluSuite nav flags so the blusuite_base sidebar renders correctly."""
    try:
        from ems_project.frontend_views import _blusuite_nav_flags
        return _blusuite_nav_flags(user)
    except Exception:
        return {}


def _get_employee_role(user):
    """Safely get employee_role, returns empty string if no employee_profile."""
    try:
        return user.employee_profile.employee_role or ''
    except Exception:
        return ''


def _can_manage_forms(user):
    """Check if user can manage form templates (admin, employer, or HR)."""
    if user.role in ['SUPERADMIN', 'ADMINISTRATOR', 'EMPLOYER_ADMIN']:
        return True
    if getattr(user, 'is_employer', False):
        return True
    return _get_employee_role(user) in ['HR', 'SUPERVISOR']


# ============================================================================
# FORM TEMPLATE MANAGEMENT
# ============================================================================

@login_required
def form_templates_list(request):
    """List all form templates — employees see available forms + their submissions"""
    is_regular_employee = (
        request.user.role == 'EMPLOYEE' and 
        hasattr(request.user, 'employee_profile') and
        request.user.employee_profile.employee_role not in ['HR', 'SUPERVISOR']
    )
    can_manage = not is_regular_employee
    
    # Employees see only active forms, admins/HR see all
    if is_regular_employee:
        templates = FormTemplate.objects.filter(
            company=request.user.company,
            status='ACTIVE'
        ).order_by('-created_at')
    else:
        templates = FormTemplate.objects.filter(
            company=request.user.company
        ).order_by('-created_at')
    
    # Filter by category
    category = request.GET.get('category')
    if category:
        templates = templates.filter(category=category)
    
    # Filter by status (admin only)
    status = request.GET.get('status')
    if status and can_manage:
        templates = templates.filter(status=status)
    
    # For employees: include their personal submissions
    my_submissions = None
    submission_stats = {}
    if request.user.role == 'EMPLOYEE':
        my_submissions = FormSubmission.objects.filter(
            submitted_by=request.user
        ).select_related('template').order_by('-created_at')
        submission_stats = {
            'total': my_submissions.count(),
            'pending': my_submissions.filter(status='PENDING').count(),
            'approved': my_submissions.filter(status='APPROVED').count(),
            'rejected': my_submissions.filter(status='REJECTED').count(),
        }
    
    context = {
        'templates': templates,
        'categories': FormTemplate.FormCategory.choices,
        'selected_category': category,
        'selected_status': status,
        'can_manage': can_manage,
        'my_submissions': my_submissions,
        'submission_stats': submission_stats,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/templates_list.html', context)


@login_required
def form_template_create(request):
    """Create a new form template"""
    if not _can_manage_forms(request.user):
        messages.error(request, 'Access denied. HR or Admin only.')
        return redirect('eforms_list')
    
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description', '')
        category = request.POST.get('category', 'GENERAL')
        requires_signature = request.POST.get('requires_signature') == 'on'
        requires_approval = request.POST.get('requires_approval') == 'on'
        approver_role = request.POST.get('approver_role', '')
        
        template = FormTemplate.objects.create(
            title=title,
            description=description,
            category=category,
            company=request.user.company,
            requires_signature=requires_signature,
            requires_approval=requires_approval,
            approver_role=approver_role,
            created_by=request.user,
            status='DRAFT'
        )
        
        messages.success(request, f'Form template "{title}" created successfully!')
        return redirect('form_builder', template_id=template.id)
    
    context = {
        'categories': FormTemplate.FormCategory.choices,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/template_create.html', context)


@login_required
def form_builder(request, template_id):
    """Form builder interface"""
    template = get_object_or_404(FormTemplate, id=template_id, company=request.user.company)
    
    if not (_can_manage_forms(request.user) or template.created_by == request.user):
        messages.error(request, 'Access denied.')
        return redirect('form_templates_list')
    
    if request.method == 'POST':
        # Save form structure from JSON
        form_fields_json = request.POST.get('form_fields')
        if form_fields_json:
            try:
                template.form_fields = json.loads(form_fields_json)
                template.status = request.POST.get('status', 'DRAFT')
                template.save()
                messages.success(request, 'Form template saved successfully!')
                return redirect('form_templates_list')
            except json.JSONDecodeError:
                messages.error(request, 'Invalid form data.')
    
    # Serialize form_fields to JSON string for safe JS embedding
    form_fields_json = json.dumps(template.form_fields if template.form_fields else {'fields': []})
    
    company = request.user.company
    
    context = {
        'template': template,
        'form_fields_json': form_fields_json,
        'field_types': FormField.FieldType.choices,
        'company': company,
        **_blusuite_ctx(request.user),
    }    
    return render(request, 'eforms/form_builder.html', context)


@login_required
def form_template_edit(request, template_id):
    """Edit form template settings"""
    template = get_object_or_404(FormTemplate, id=template_id, company=request.user.company)
    
    if not (_can_manage_forms(request.user) or template.created_by == request.user):
        messages.error(request, 'Access denied.')
        return redirect('form_templates_list')
    
    if request.method == 'POST':
        template.title = request.POST.get('title')
        template.description = request.POST.get('description', '')
        template.category = request.POST.get('category')
        template.requires_signature = request.POST.get('requires_signature') == 'on'
        template.requires_approval = request.POST.get('requires_approval') == 'on'
        template.approver_role = request.POST.get('approver_role', '')
        template.header_style = request.POST.get('header_style', 'logo_left')
        template.status = request.POST.get('status')
        template.save()
        
        messages.success(request, 'Template updated successfully!')
        return redirect('form_templates_list')
    
    # Serialize form_fields to JSON string for safe JS embedding
    form_fields_json = json.dumps(template.form_fields if template.form_fields else {'fields': []})
    
    context = {
        'template': template,
        'categories': FormTemplate.FormCategory.choices,
        'form_fields_json': form_fields_json,
        'company': request.user.company,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/template_edit.html', context)


@login_required
@require_http_methods(["POST"])
def form_template_delete(request, template_id):
    """Delete a form template (admin/HR only)"""
    template = get_object_or_404(FormTemplate, id=template_id, company=request.user.company)
    
    if not _can_manage_forms(request.user):
        messages.error(request, 'Access denied. Only admins and HR can delete templates.')
        return redirect('form_templates_list')
    
    title = template.title
    template.delete()
    messages.success(request, f'Form template "{title}" has been deleted.')
    return redirect('form_templates_list')


# ============================================================================
# FORM SUBMISSION
# ============================================================================

@login_required
def form_fill(request, template_id):
    """Fill out a form (or preview for admins)"""
    template = get_object_or_404(
        FormTemplate, 
        id=template_id, 
        company=request.user.company,
    )
    
    # Determine if this is a preview (admin/creator viewing) or fill (employee submitting)
    is_preview = (
        request.GET.get('preview') == '1'
        or _can_manage_forms(request.user)
        or template.created_by == request.user
    )
    
    # Non-active templates can only be previewed, not filled
    if template.status != 'ACTIVE' and not is_preview:
        messages.error(request, 'This form is not currently active.')
        return redirect('eforms_list')
    
    if request.method == 'POST' and not is_preview:
        # Collect form data
        form_data = {}
        for key, value in request.POST.items():
            if key not in ['csrfmiddlewaretoken', 'action']:
                form_data[key] = value
        
        # Create or update submission
        submission_id = request.POST.get('submission_id')
        if submission_id:
            submission = get_object_or_404(
                FormSubmission, 
                id=submission_id, 
                submitted_by=request.user
            )
            submission.form_data = form_data
        else:
            submission = FormSubmission.objects.create(
                template=template,
                submitted_by=request.user,
                company=request.user.company,
                form_data=form_data,
                status='DRAFT'
            )
        
        action = request.POST.get('action')
        if action == 'submit':
            submission.submit()
            
            if template.requires_signature:
                messages.info(request, 'Form submitted! Please add your signature.')
                return redirect('form_sign', submission_id=submission.id)
            else:
                messages.success(request, 'Form submitted successfully!')
                return redirect('form_submissions_list')
        else:
            submission.save()
            messages.success(request, 'Form saved as draft.')
            return redirect('form_submissions_list')
    
    # Get form fields from the FormField model
    fields = template.fields.all().order_by('order')
    
    # Also parse JSON form_fields for backward compatibility
    json_fields = template.form_fields.get('fields', []) if isinstance(template.form_fields, dict) else []
    
    # Serialize form_fields to JSON string for safe JS embedding
    form_fields_json = json.dumps(template.form_fields if template.form_fields else {'fields': []})
    
    context = {
        'template': template,
        'fields': fields,
        'json_fields': json_fields,
        'form_fields_json': form_fields_json,
        'company': request.user.company,
        'is_preview': is_preview,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/form_fill.html', context)


@login_required
def form_submissions_list(request):
    """List user's form submissions"""
    submissions = FormSubmission.objects.filter(
        submitted_by=request.user
    ).select_related('template').order_by('-created_at')
    
    # Filter by status
    status = request.GET.get('status')
    if status:
        submissions = submissions.filter(status=status)
    
    context = {
        'submissions': submissions,
        'selected_status': status,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/submissions_list.html', context)


@login_required
def form_submission_detail(request, submission_id):
    """View form submission details"""
    submission = get_object_or_404(
        FormSubmission, 
        id=submission_id,
        company=request.user.company
    )
    
    # Check permission
    if not (submission.submitted_by == request.user or _can_manage_forms(request.user)):
        messages.error(request, 'Access denied.')
        return redirect('form_submissions_list')
    
    context = {
        'submission': submission,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/submission_detail.html', context)


@login_required
def submission_export_pdf(request, submission_id):
    """Export a form submission as a professional PDF document"""
    from django.template.loader import get_template
    from django.http import HttpResponse

    if _pisa is None:
        return HttpResponse('PDF generation is not available. Please install xhtml2pdf.', status=500)

    submission = get_object_or_404(
        FormSubmission,
        id=submission_id,
        company=request.user.company
    )

    # Check permission
    if not (submission.submitted_by == request.user or _can_manage_forms(request.user)):
        messages.error(request, 'Access denied.')
        return redirect('form_submissions_list')

    # Get form structure and submitted data
    form_fields = submission.template.form_fields
    fields_list = form_fields.get('fields', []) if isinstance(form_fields, dict) else []
    form_data = submission.form_data if isinstance(submission.form_data, dict) else {}

    # Build display-ready field data
    rendered_fields = []
    for field in fields_list:
        fid = field.get('id', '')
        ftype = field.get('type', 'TEXT')
        label = field.get('label', '')
        value = form_data.get(fid, '')

        rendered_fields.append({
            'type': ftype,
            'label': label,
            'value': value,
            'required': field.get('required', False),
            'options': field.get('options', []),
            'width': field.get('width', 'full'),
            'helpText': field.get('helpText', ''),
        })

    # Get signature if exists
    signature = submission.signatures.first()

    # Get approval info
    approval = submission.approvals.first()

    # Company info
    company = submission.company
    
    # Get absolute path for company logo (xhtml2pdf needs file:// paths)
    company_logo_path = ''
    if company.logo:
        try:
            company_logo_path = company.logo.path
        except Exception:
            company_logo_path = ''

    context = {
        'submission': submission,
        'template': submission.template,
        'rendered_fields': rendered_fields,
        'signature': signature,
        'approval': approval,
        'company': company,
        'company_logo_path': company_logo_path,
        'generated_at': timezone.now(),
    }

    # Render HTML template
    pdf_template = get_template('eforms/pdf_export.html')
    html = pdf_template.render(context)

    # Generate PDF
    result = BytesIO()
    pdf = _pisa.pisaDocument(BytesIO(html.encode('utf-8')), result)

    if pdf.err:
        return HttpResponse('Error generating PDF', status=500)

    # Return PDF response
    response = HttpResponse(result.getvalue(), content_type='application/pdf')
    filename = f"{submission.template.title.replace(' ', '_')}_{submission.id}.pdf"
    
    # Check if user wants to download or view inline
    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response['Content-Disposition'] = f'{disposition}; filename="{filename}"'
    return response


# ============================================================================
# E-SIGNATURE
# ============================================================================

@login_required
def form_sign(request, submission_id):
    """Sign a form submission"""
    submission = get_object_or_404(
        FormSubmission, 
        id=submission_id,
        submitted_by=request.user
    )
    
    if not submission.template.requires_signature:
        messages.error(request, 'This form does not require a signature.')
        return redirect('form_submission_detail', submission_id=submission.id)
    
    # Check if already signed
    existing_signature = ESignature.objects.filter(
        submission=submission,
        signer=request.user
    ).first()
    
    if request.method == 'POST':
        signature_type = request.POST.get('signature_type')
        signature_data = request.POST.get('signature_data')
        consent = request.POST.get('consent') == 'on'
        
        if not consent:
            messages.error(request, 'You must agree to the consent terms.')
            return redirect('form_sign', submission_id=submission.id)
        
        # Get IP and user agent
        ip_address = request.META.get('REMOTE_ADDR')
        user_agent = request.META.get('HTTP_USER_AGENT', '')
        
        consent_text = f"I, {request.user.get_full_name()}, electronically sign this document and agree that this signature is legally binding."
        
        signature = ESignature.objects.create(
            submission=submission,
            signer=request.user,
            signature_type=signature_type,
            signature_data=signature_data,
            ip_address=ip_address,
            user_agent=user_agent,
            consent_text=consent_text,
            consented=True
        )
        
        # Create audit log
        SignatureAuditLog.objects.create(
            signature=signature,
            action='CREATED',
            performed_by=request.user,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        messages.success(request, 'Form signed successfully!')
        return redirect('form_submission_detail', submission_id=submission.id)
    
    context = {
        'submission': submission,
        'existing_signature': existing_signature,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/form_sign.html', context)


@login_required
def signature_audit_trail(request, signature_id):
    """View signature audit trail"""
    signature = get_object_or_404(ESignature, id=signature_id)
    
    # Check permission
    if not (signature.signer == request.user or _can_manage_forms(request.user)):
        messages.error(request, 'Access denied.')
        return redirect('eforms_list')
    
    audit_logs = signature.audit_logs.all()
    
    context = {
        'signature': signature,
        'audit_logs': audit_logs,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/signature_audit.html', context)


# ============================================================================
# FORM APPROVALS
# ============================================================================

@login_required
def form_approvals_list(request):
    """List forms pending approval"""
    # Check if user can approve forms
    if not _can_manage_forms(request.user):
        messages.error(request, 'Access denied. Insufficient permissions.')
        return redirect('eforms_list')
    
    # Get pending approvals assigned to this user
    my_approvals = FormApproval.objects.filter(
        approver=request.user,
        status='PENDING'
    ).select_related('submission', 'submission__template', 'submission__submitted_by')
    
    # Get all pending submissions (for HR/Admin)
    all_pending = FormSubmission.objects.filter(
        company=request.user.company,
        status='PENDING_APPROVAL'
    ).select_related('template', 'submitted_by')
    
    context = {
        'my_approvals': my_approvals,
        'all_pending': all_pending,
        **_blusuite_ctx(request.user),
    }
    
    return render(request, 'eforms/approvals_list.html', context)


@login_required
@require_http_methods(["POST"])
def form_approve_reject(request, submission_id):
    """Approve or reject a form submission"""
    submission = get_object_or_404(
        FormSubmission, 
        id=submission_id,
        company=request.user.company
    )
    
    action = request.POST.get('action')
    comments = request.POST.get('comments', '')
    
    # Check permission
    if not _can_manage_forms(request.user):
        messages.error(request, 'Access denied.')
        return redirect('form_approvals_list')
    
    if action == 'approve':
        submission.status = 'APPROVED'
        submission.approved_by = request.user
        submission.approved_at = timezone.now()
        submission.save()
        
        # Update approval record if exists
        FormApproval.objects.filter(
            submission=submission,
            approver=request.user
        ).update(
            status='APPROVED',
            comments=comments,
            reviewed_at=timezone.now()
        )
        
        messages.success(request, f'Form submitted by {submission.submitted_by.get_full_name()} approved!')
    
    elif action == 'reject':
        submission.status = 'REJECTED'
        submission.rejection_reason = comments
        submission.save()
        
        # Update approval record if exists
        FormApproval.objects.filter(
            submission=submission,
            approver=request.user
        ).update(
            status='REJECTED',
            comments=comments,
            reviewed_at=timezone.now()
        )
        
        messages.success(request, f'Form submitted by {submission.submitted_by.get_full_name()} rejected.')
    
    return redirect('form_approvals_list')
