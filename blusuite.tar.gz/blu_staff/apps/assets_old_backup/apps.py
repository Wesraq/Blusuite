from django.apps import AppConfig


class AssetsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    # Expose as 'assets' module (via APPS_ROOT) to keep migrations and URLs aligned
    name = 'assets'
    label = 'assets'
    verbose_name = 'Asset Management'
