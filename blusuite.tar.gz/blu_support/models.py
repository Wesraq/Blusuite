from django.db import models

# Create your models here.


class SupportTicket(models.Model):
    class Priority(models.TextChoices):
        LOW = 'LOW', 'Low'
        NORMAL = 'NORMAL', 'Normal'
        HIGH = 'HIGH', 'High'
        URGENT = 'URGENT', 'Urgent'

    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open'
        IN_PROGRESS = 'IN_PROGRESS', 'In Progress'
        RESOLVED = 'RESOLVED', 'Resolved'
        CLOSED = 'CLOSED', 'Closed'

    company = models.ForeignKey(
        'accounts.Company',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='support_tickets',
    )
    created_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_support_tickets',
    )
    subject = models.CharField(max_length=200)
    description = models.TextField()
    priority = models.CharField(
        max_length=10,
        choices=Priority.choices,
        default=Priority.NORMAL,
    )
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.OPEN,
    )
    category = models.CharField(max_length=50, blank=True)
    reference = models.CharField(max_length=20, unique=True, editable=False)
    contact_email = models.EmailField(blank=True)
    last_response_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.reference}] {self.subject}" if self.reference else self.subject

    def save(self, *args, **kwargs):
        if not self.reference:
            # Simple human-friendly reference like ST-000123
            prefix = 'ST-'
            last_id = (
                SupportTicket.objects.order_by('-id').values_list('id', flat=True).first()
            ) or 0
            self.reference = f"{prefix}{last_id + 1:06d}"
        super().save(*args, **kwargs)


class KnowledgeArticle(models.Model):
    """Knowledge base article for tenant/company portals."""

    class Visibility(models.TextChoices):
        TENANTS = 'TENANTS', 'All Tenants'
        INTERNAL = 'INTERNAL', 'Internal Only'

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True)
    summary = models.TextField(blank=True)
    content = models.TextField()
    video_url = models.URLField(blank=True, help_text="Optional link to a training video or external resource.")
    media_file = models.FileField(
        upload_to='knowledge_base/',
        blank=True,
        null=True,
        help_text="Optional uploaded media (video, image or PDF) stored in the platform.",
    )
    category = models.CharField(max_length=100, blank=True)
    visibility = models.CharField(
        max_length=20,
        choices=Visibility.choices,
        default=Visibility.TENANTS,
    )
    is_published = models.BooleanField(default=True)
    created_by = models.ForeignKey(
        'accounts.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='knowledge_articles',
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
